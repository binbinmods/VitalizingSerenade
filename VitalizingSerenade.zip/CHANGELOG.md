# 0.1.2

Purple Lute of Life is now an accessory.

Ring of Song works with songs ≥3.

# 0.1.1

Added additional guaranteed drops

Cuirass of Heart now increases healing too.

Guaranteed that you can go to the Stolen Items in Faeborg

All Cards are displayed as Vitalizing Serenade

Numerous smaller bug fixes

# 0.1.0

Initial pre-release.
