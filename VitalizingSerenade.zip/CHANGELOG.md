# 0.1.1

Added additional guaranteed drops

Cuirass of Heart now increases healing too.

Guaranteed that you can go to the Stolen Items in Faeborg

All Cards are displayed as Vitalizing Serenade

Numerous smaller bug fixes

# 0.1.0

Initial pre-release.
